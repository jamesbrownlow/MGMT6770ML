# DataScience
Materials for CSUB class, book by Hadley Wickham
This repository contains reading material and assignments for CSUB class Data Analytics for Business.
It contains R code and slide presentations

